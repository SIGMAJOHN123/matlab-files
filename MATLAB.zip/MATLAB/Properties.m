function [pa, Ta, sa, nxn, MX, cpX, Mf, rhof, Tai, Hf, SX] = Properties(fuel)
% returns the needed variables depending on the type of fuel you need

pa = 101325; % pa
Ta = 273 ; %Kelvin
sa = 4000 ; % J/(kg*K)
nxn = readmatrix("AirProperties.xlsx",'Range','B2:F2');  %nx(i)/n
MX = readmatrix("AirProperties.xlsx","Range",'B3:F3'); %kg/mol
cpX = readmatrix('AirProperties.xlsx','Range','B4:F4'); %J/(kg*mol)


switch fuel % these are taken from fuel properties and reaction properties chart
    case {"Gasoline" ,"Octane",  "gasoline"}
        
Mf = readcell('FuelProperties.xlsx','Range','B2:B2'); %kg/mol
rhof = readcell('FuelProperties.xlsx','Range','C2:C2'); %kg/mol^3
Tai = readcell('FuelProperties.xlsx','Range','D2:D2'); %Kelvin
Hf = readcell('FuelProperties.xlsx','Range','E2:E2'); %J*kg-1
SX = readmatrix('ReactionRatios.xlsx','Range','B2:F2');%X(i)

    case {"diesel" "Diesel"}
        
Mf = readcell('FuelProperties.xlsx','Range','B3:B3'); %kg/mol
rhof = readcell('FuelProperties.xlsx','Range','C3:C3'); %kg/mol^3
Tai = readcell('FuelProperties.xlsx','Range','D3:D3'); %Kelvin
Hf = readcell('FuelProperties.xlsx','Range','E3:E3'); %J*kg-1
SX = readmatrix('ReactionRatios.xlsx','Range','B3:F3'); %X(i)

    otherwise

Mf = NaN;
rhof = NaN;
Tai = NaN;
Hf = NaN;
SX = NaN;
pa = NaN;
Ta = NaN;
sa = NaN;
nxn = NaN;
MX = NaN;
cpX = NaN;

end


