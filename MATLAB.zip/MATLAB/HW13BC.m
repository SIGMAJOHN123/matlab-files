A = [-1 0 3 1; 2 -2 0 -3; -3 1 -1 2; -2 -1 2 0]
b = [-4 ; -18; 16; -6]
r = rank(A)
rb = rank(b)
rab = r/rb
x = A\b
