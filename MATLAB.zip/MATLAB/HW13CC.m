A = [1 -1 0; -1 2 -1; 0 -1 1];
ec = rref(A)

l1 =zeros(3,3)
l2 = [1 0 0;0 1 0; 0 0 1]
l3 = [3 0 0;0 3 0;0 0 3]



il1 = inv(l1)
il2 = inv(l2)
il3 = inv(l3)



d1 = il1 .* (A .* l1)
d2 = il2 .* (A .* l2)
d3 = il3 .* (A .* l3)