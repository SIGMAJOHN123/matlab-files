function [P_IG, P_vdW,P_RK] = IGPressurearray(n, T, V)
% calculates Ideal gas Pressure
%   Takes variables T, n, and V which are tempurature in Kelvin, kmols of
%   air, and the volume to calculate the ideal gas pressure.
Ru = 0.08314; %[(bar*m^3)/(Kmol*K)] universal gas constant   
% n = kmols of air
% T = temperature in Kelvin
% V = m^3
% air constants 
a = 1.368;
b = 0.0367;
c = 15.989;
d = 0.02541;

P_IG = (n*Ru*T)/V

P_vdW = ((Ru*T)/((V/n)-b))-(a/((V/n)^2))

P_RK = ((Ru*T)/((V/n)-d))-(c/((V/n)*(sqrt(T)*((V/n)+d))))


end