
[P_IG_1, P_vdW_1,P_RK_1] = IGPressure(0.25, 300, 0.115)


[P_IG_2, P_vdW_2,P_RK_2] = IGPressure(0.5, 325, 0.325)


[P_IG_3, P_vdW_3,P_RK_3] = IGPressure(0.75, 350, 0.575)

[P_IG_4, P_vdW_4,P_RK_4 ] = IGPressure(1, 375, 0.735)


RD_vdW_1 = ((abs(P_vdW_1-P_IG_1))/P_IG_1)*100

RD_RK_1 = ((abs(P_RK_1-P_IG_1))/P_IG_1)*100

RD_vdW_2 = ((abs(P_vdW_2-P_IG_2))/P_IG_2)*100

RD_RK_2 = ((abs(P_RK_2-P_IG_2))/P_IG_2)*100

RD_vdW_3 = ((abs(P_vdW_3-P_IG_3))/P_IG_3)*100

RD_RK_3 = ((abs(P_RK_3-P_IG_3))/P_IG_3)*100

RD_vdW_4 = ((abs(P_vdW_4-P_IG_4))/P_IG_4)*100

RD_RK_4 = ((abs(P_RK_4-P_IG_4))/P_IG_4)*100