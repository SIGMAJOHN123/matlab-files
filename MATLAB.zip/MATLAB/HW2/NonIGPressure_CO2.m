function [vmol,P_CO2] = NonIGPressure_CO2(v,T)
% NonIGPRessure
%   Detailed explanation goes here
a =  0.1386;
A = 2.7737;
b = .00721;
B = .04991;
c = 1.512E4;
C = 1.404E5;
alpha =  8.47E-5; 
gamma = .00539;
M = 44;
Ru = 8.314;
vmol = v*M;
P_CO2 = ((Ru*T)/vmol)+(((B*Ru*T)-A-(C/(T^2)))*(vmol^-2)) + (((((b*Ru*T)-a)/(vmol^3))))+((a*alpha)/(vmol^6))+((c/((vmol^3)*(T^2)))*(1+(gamma/(vmol^2)))*exp(-gamma/(vmol^2))); 
end




