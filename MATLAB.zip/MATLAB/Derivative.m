function [D] = Derivative(x,y)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

if length(x) == length(y)
    N = length(x);
    D = zeros(1,N);
    h = x(2) - x(1) ;

D(N) = (y(N-2) - 4*y(N-1) + 3*y(N)) / (2*h);

    D(1) = (-3*y(1) + 4*y(2) - y(3)) / (2*h) ;
 
for i = 2:N-1
    D(i) = (y(i+1) - y(i-1)) / (2*h);
end

end
end

