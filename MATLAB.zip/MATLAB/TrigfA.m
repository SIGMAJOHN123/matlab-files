function [y,N] = TrigfA(x,tol)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
format("long")
[r,c]=size(x);
N = zeros(r,c);
y = zeros(r,c);
for i = 1:numel(x)
    

if x(i) <= -1
yn = -pi/2;


 
    for n = 1:100
yn = yn - (-1)^n * 1 / ((2*n + 1) * (x(i)^(2*n + 1)));


if abs((-1)^n * 1 / ((2*n + 1) * (x(i)^(2*n + 1)))) < tol
    break
end
N(i) = n+1;
y(i) = yn;
    end






elseif x(i)>-1 && x(i)<1
yn = 0;
n = 1;

while n < 100
    

    yn = yn +(-1)^n * (x(i)^(2*n + 1)) / (2*n + 1);
if abs((-1)^n * (x(i)^(2*n + 1)) / (2*n + 1)) < tol
    break
end 
    n = n+1;

end

N(i) = n;
y(i) = yn;
elseif x(i) >= -1
yn = pi/2;
n = 1;


while n >= 0 
yn = yn - (-1)^n * (1 / ((2*n + 1) .* x(i)^(2*n + 1)));
n = n + 1;
if abs((-1).^n * (1 / ((2*n + 1) * x(i).^(2*n + 1)))) <tol
break
end
N(i)=n+1;
y(i)=yn;
end

end

end