function [M,MB,MTL,MTR,MTT,MTB,S] = ChestPatternTrimmer(n)


    M = eye(3*n,3*n) ;
    M([1:n*3] [n,)=1
    MB =2;i
    MTL = 2;
    MTR =2;
    MTT = 2;
    MTB =2;
    S =size(M);size(MB);size(MTL);size(MTR);size(MTT);size(MTB);
end
