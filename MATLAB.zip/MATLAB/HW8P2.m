
r = linspace(0.001,10,1000);
s = zeros(0,numel(ls));

for i= 1:1000 
s(i)= 0.75 * r(i)^3 * exp(0.75 * r(i));

end

xmin = min(r);
xmax = max(r);
ymin = min(s);
ymax = max(s);
limits = [xmin xmax ymin ymax];


figure(4)
subplot(2,2,1)

plot(r,s,':r')
axis(max(s));
xlabel('r')
ylabel('s')
grid on
axis tight
axis(limits)

subplot(2,2,2)

semilogy(r,s,'--g')
xlabel('r')
axis(max(s));
ylabel('s')
grid on
axis tight
axis(limits)
subplot(2,2,3)


semilogx(r,s,'.-b')
axis(max(s));
xlabel('r')
ylabel('s')
grid on

axis tight
axis(limits)
subplot(2,2,4)

loglog(r,s,'y')

xlabel('r')
ylabel('s')
grid on
axis tight
axis(limits)