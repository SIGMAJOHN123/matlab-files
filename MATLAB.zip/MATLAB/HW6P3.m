

bufftemp = importdata("Buffalo_Temperature_2014_2025.xlsx");
Buff_Temp_14_25 = readmatrix("Buffalo_Temperature_2014_2025.xlsx",'range','B2:M13');
Year = readmatrix("Buffalo_Temperature_2014_2025.xlsx",'range', 'B1:M1');
Month = bufftemp.rowheaders(2:13);
Tavg_14_25 = zeros(1,12);
Tmax_14_25 = zeros(1,12);
Tmin_14_25 = zeros(1,12);

for n = 1:12
    
ean = mean(Buff_Temp_14_25(n,:));
ax = max(Buff_Temp_14_25(n,:));
in = min(Buff_Temp_14_25(n,:));
   
Tavg_14_25(n) = ean;
Tmax_14_25(n) = ax;
Tmin_14_25(n) = in;
end


maxT = max(Tmax_14_25);
indax = find(maxT==Tmax_14_25);

Hottest_Y = Year(indax);
    
minT = min(Tmin_14_25);
indin = find(minT==Tmin_14_25);
Coldest_Y = Year(indin);

 t = Buff_Temp_14_25(:,9) > Buff_Temp_14_25(:,10);
indmonth = find(t);
Mon_22_H_23 = Month(indmonth);
 

NoM_22_H_23 = sum(t);