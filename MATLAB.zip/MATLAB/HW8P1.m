t = 0:10;
lx = length(t);
x = zeros(1,lx);

for i = 1:11
x(i) = 3*(t(i)^2) - 5*(t(i)^3)*sin(t(i)/2) -8*t(i) + 20 ;


end

v = Derivative(t,x);
a = Derivative(t,v);
figure('Name','bleh')
plot(t, x, '-.b', t, v,'--r', t, a, ':', 'LineWidth',1)

title('function x and its derivatives')
grid on
xlabel('t = time')
ylabel('distance, velocity & acceleration')
legend('distance', 'velocity', 'acceleration')


figure(2)
set(figure(2),'name','boo')
fplot(x, [0 10], ':b')  ; 
hold on
fplot(v , [0 10], '--r')  ; 
fplot(a, [0 10], '-.g')   ; 
hold off
legend('x','v','a')



figure(3)
set(figure(3),'name', 'rahaha')

subplot(2,2,1)
plot(t, x,':b')
title('function x')
xlabel('t = time')
grid on
ylabel('distance')
legend('distance')

subplot(2,2,2)
plot(t, v, '--r')
xlabel('t = time')
title('velocity')
grid on
ylabel('velocity')
legend('velocity')

subplot(2,2,3)
plot(t, a, '-.g')
ylabel('acceleration')
title('function a')
grid on
xlabel('t = time')
legend('acceleration')
