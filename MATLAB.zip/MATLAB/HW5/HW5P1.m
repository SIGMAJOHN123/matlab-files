[vmol,P]= NonIGPressure_Gasses( .55, 300);
fileId = fopen('HW5P1_Data.csv','w');
Gas = transpose([1:1:5]);
transpose(vmol);
transpose(P);
GasPvmol = [Gas , P , vmol];
chart = mat2str(GasPvmol);


txt = sprintf("For X.XX m^3kg of gas at a temperature of XXX K,\nthe pressure and molar volume depend on the type of gas as shown below:\n\n     Gas        P       vmol \n     Number     kPa     m3/kg\n\n     _____________________ \n     ");
txt2 = sprintf('where Gas(1) = C4H10, Gas(2) = C02, Gas(3) = CH4, Gas(4) = C0, Gas(5) = N2\n');
disp(txt);
disp(GasPvmol)
disp(txt2)

T = transpose(linspace(285,325,5));
v = transpose(linspace(.15,.55,5));
Gases = ["C4H10";"C02";"CH4";"C0";"N2"];
mat2str(vmol);
mat2str(P);
mat2str(v);
mat2str(T);
mat2str(vmol);
GasesTvPvmol_str = [Gases T v P vmol];
mat2str(GasesTvPvmol_str);
save fileId GasesTvPvmol_str ;
GasesTvPvmol_chart=transpose (GasesTvPvmol_str);
fprintf('The ideal gases pressure and molar volume as a function of the gas type,\nthe temperature, and the specific volume are:');
fprintf('For %s​ gas at a temperature of %s K and a specific volume of %s m^3/kg,\nthe pressure is %s kPa and the molar specific volume is %s m^3/kmol.\n\n',GasesTvPvmol_chart);
