Air_Data = load("IGData.txt");

n = Air_Data(:,1);
V = Air_Data(:,2);
T = Air_Data(:,3);
[P_IG, P_vdW,P_RK] = IGPressure_Array(n, T, V);
RD_vdW = ((abs(P_vdW-P_IG))./(P_IG))*100;
RD_RK = (((abs(P_RK-P_IG))./(P_IG)))*100;
IGPressure_Data = transpose([n V T P_IG P_vdW P_RK RD_vdW RD_RK]);
format short
save IGData_Complete.txt IGPressure_Data -ascii
fprintf('     n     V   T    P_IG  P_vdW   P_RK  RD_vdW  RD_RK\n')
disp('[kmol] [m^3]  [K]  [bar]  [bar]  [bar]   [%]    [%]');
format short
fprintf('%.2f %.2f %.f %.4f %.4f %.4f %.4f %.4f\n' , IGPressure_Data)
