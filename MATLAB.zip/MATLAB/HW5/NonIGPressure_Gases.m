function [vmol,P_Gas] = NonIGPressure_Gases(v,T)
% NonIGPRessure

a =  readmatrix("GasConstants.xlsx",'Range','C2:C6');
A = readmatrix("GasConstants.xlsx",'Range','D2:D6');
b = readmatrix("GasConstants.xlsx",'Range','E2:E6');
B = readmatrix("GasConstants.xlsx",'Range','F2:F6');
c = readmatrix("GasConstants.xlsx",'Range','G2:G6');
C = readmatrix("GasConstants.xlsx",'Range','H2:H6');
alpha =  readmatrix("GasConstants.xlsx",'Range','I2:I6');
gamma = readmatrix("GasConstants.xlsx",'Range','J2:J6');
M = readmatrix("GasConstants.xlsx",'Range','B2:B6');
Ru = 8.314;


vmol = (v).*M;
P_Gas = (((Ru).*(T))./vmol)+((((B).*(Ru).*(T))-A-((C)./((T).^2))).*((vmol).^-2)) + ((((((b).*(Ru).*(T))-a)./((vmol).^3))))+(((a).*(alpha))./((vmol).^6))+(((c)./(((vmol).^3).*((T).^2))).*(1+((gamma)./((vmol).^2))).*exp(-(gamma)./((vmol).^2))); 
end




