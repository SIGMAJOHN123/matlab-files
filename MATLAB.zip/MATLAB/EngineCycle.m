function [Kine,Therm,Chem,Diag,DDT] = EngineCycle(D,d,rpm,fuel)
% Describes the cycle of the engine depending on what you input

Ru = 8.3145; %J/mol*K
k = 1;
N = 256; % iterations 
L = .10; %m
V = zeros(1,N);
V(1) = 6E-5 ;%m^3
Dv = .02; %m
Kine = zeros(4,N);
Therm = zeros(4,N);
Chem = zeros(12,N);
Diag = zeros(4,1);
DDT = false;
CR = ( V(1)+ (D*((pi * d^2)/4)))/V(1);
CF = (1 + 8*(rpm-800 /5200))*(CR-6.854);
CE = (.45 + 3*(rpm-800 / 5200))*(1+ (CR-8.854/4));
IGN = pi/6;
EXH = pi/6;

lomega = 2*pi*(rpm/60); % radians/second
xp = zeros(1,N);
phi = zeros(1,N);
t = zeros(1,N);
mCO2 = zeros(1,5);

dt = t(2)-t(1);


% initial state

[pa, Ta, sa, nxn, MX, cpX, Mf, ~, Tai, Hf, SX] = Properties(fuel);
n = zeros(1,N);
m = zeros(1,N);
p =zeros(1,N);
T = zeros(1,N);
v = zeros(1,N);
R = zeros(1,N);
cp = zeros(1,N);
cv = zeros(1,N);
W = zeros(1,N);
s = zeros(1,N);
nX = zeros(5,N);
muX = zeros(5,N);
DDT = false;
p(1) = pa;
T(1) = Ta;
s(1) = sa;

n(1) = (p(1)*V(1)) / (Ru*T(1));
MX(:,1) = transpose(MX);
nX(:,1) = transpose(nxn);
MMW = 0;

for i = 1:5
MMW =  ((m(i)*nX(i,k))/n(1))  + MMW ; 
cp(1) = muX(i)*cpX(i) +cp(1) ;
end


R(1) = Ru/MMW;
cv(1) = cp(1) -R(1);
v(1) = V(1)/m(1);

for i = 1:5
    
    size(nX)
    size(MX)
    m(1) = m(i) +dot(nX,MX); % total mass
    muX(i) = nX(i)*MX(i) /m; %mass fractions 

end


for k = 1:N
phi(k+1) = 4*pi* ((k-1)/(N-1)) ;
t(k+1) = 4*pi*(k-1) / lomega*(N-1);
xp(k+1) = D/2  *(cos(phi(t))+sqrt(4* L^2 /(D^2)  - sin(phi(k)^2)));
V(k+1) = V(1) + (pi* d^2 /4 * (L+ D/2 - xp(t)));



while 0 <= phi && phi <pi
p(k+1) = p(k);

T(k+1) = T(k);

for i = 1:5

nX(i,k+1) = nX(i,k)*(V(k+1)/V(k));
muX(i,k+1) = muX(i,k);

end

n(k+1) = n(k)*(V(k+1)/V(k));
m(k+1) = m(k)*(V(k+1)/V(k));
R(k+1) = R(k);
cp(k+1) = cp(k);
cv(k+1) = cv(k);
v(K+1) = V(K);


end



switch fuel
    case 'Gasoline' , 'Octane';  'gasoline';
while pi <= phi &&phi < 2*pi - IGN 

for i = 1:5
   nX(i,k+1) = nX(i,k);
   muX(i,k+1) = muX(i,k);
end
n(k+1) = n(k)*(V(k+1)/V(k));
m(k+1) = m(k)*(V(k+1)/V(k));
R(k+1) = R(k);
cp(k+1) = cp(k);
cv(k+1) = cv(k);
v(K+1) = V(K+1)/m(k+1);
p(k+1) = p(k)*((v(k)/v(k+1))^(cp(k+1)/cv(k+1)));
T(k+1) = (p(k+1)*v(k+1))/R(k+1);
if T(k+1) >= Tai
   

DDT = true;

end
end
while phi(k) >= 2*pi - IGN

mf = CF/1000;

CF = (1 + 8 * ((rpm - 800) / 5200)) * (CR - 6.854);
nF = mf /Mf;

for i =1:5

nX(i,k+1) = nX(i,k) + (dt*nF*SX(i));

end
if nX(2,k+1) >=0

    f = 1;
elseif nX(2,k+1)<0

    f = nX(2,k) /(nX(2,k) - nX(2,k+1));
end
v(k+1) = V(k+1)/m(k+1);
x = [p(k+1);T(k+1)];
A = [v(k+1)*p(k+1) - (R(k+1)*T(k+1));-1*v(k+1)*p(k+1) + (cp(k+1)*T(k+1))];
b = [0;f*((Hf*mf)/m(k+1))*dt - (v(k+1)*p(k))+ (cp(k+1)*T(k))];
x =A/ b;
mf(k+1) = mf(k) + (f*mf*dt);

end
while phi(k) < 3*pi -EXH

for i = 1:5
   nX(i,k+1) = nX(i,k);
   muX(i,k+1) = muX(i,k);
end
n(k+1) = n(k)*(V(k+1)/V(k));
m(k+1) = m(k)*(V(k+1)/V(k));
R(k+1) = R(k);
cp(k+1) = cp(k);
cv(k+1) = cv(k);
v(K+1) = V(K+1)/m(k+1);
p(k+1) = p(k)*((v(k)/v(k+1))^(cp(k+1)/cv(k+1)));
T(k+1) = (p(k+1)*v(k+1))/R(k+1);
if T(k+1) >= Tai
   
DDT = true;
end
end
while (3*pi) -EXH <=phi(k) && phi(k) < 4*pi
for i = 1:5

    muX(i,k+1) = muX(i,k);
end

gamma = cp(k)/cv(k);
R(k+1) = R(k);
cp(k+1) = cp(k);
cv(k+1) = cv(k);
mE = CE * ((pi*(Dv^2))/4)* (p(k)/sqrt(R(k)*T(k)))*nthroot(pa/p(k),gamma)*sqrt((gamma*2)/(gamma-1)*(1-((pa/p(k))^((gamma-1)/gamma))));
CE = (.45+(3*((rpm-800)/5200)))*(1+(CR-8.854)/4);


end
while mE*dt< m(k)

m(k+1) = m(k) - (dt*mE);
n(k+1) = n(k) - ((dt*mE)/MMW);
for i =1:5

nX(i,k+1) = nX(i,k)*(n(k+1)/n(k));

end
mCO2 = mCO2 +(dt*mE*muX(5));


end
while mE*dt >= m(k)
for i =1:5

nX(i,k+1) = nX(i,k) * (V(k+1)/V(k)) ;

end
n(k+1) = n(k) * (V(k+1)/V(k));
m(k+1) = m(k) * (V(k+1)/V(k));
mCO2 = mCO2 + (dt*(m(k)-m(k+1))*muX(5));
v(k+1) = (V(k+1)/m(k+1));
p(k+1) = p(k)*((v(k)/v(k+1))^(cp(k+1)/cv(k+1)));
T(k+1) = p(k+1)*v(k+1)  / R(k+1);
if p(k+1)<pa

p(k+1) = pa;
v(k+1) =v(k);
T(k+1) = (pa*v(k+1))/R(k+1);
end
end
case 'diesel' ,'Diesel';

while T(k) < Tai

for i = 1:5
   nX(i,k+1) = nX(i,k);
   muX(i,k+1) = muX(i,k);
end
n(k+1) = n(k)*(V(k+1)/V(k));
m(k+1) = m(k)*(V(k+1)/V(k));
R(k+1) = R(k);
cp(k+1) = cp(k);
cv(k+1) = cv(k);
v(K+1) = V(K+1)/m(k+1);
p(k+1) = p(k)*((v(k)/v(k+1))^(cp(k+1)/cv(k+1)));
T(k+1) = (p(k+1)*v(k+1))/R(k+1);
end
while nX(2,k) > 0

mf = CF/1000;

CF = (1 + 8 * ((rpm - 800) / 5200)) * (CR - 6.854);
nF = mf /Mf;

for i =1:5

nX(i,k+1) = nX(i,k) + (dt*nF*SX(i));

end
if nX(2,k+1) >=0

    f = 1;
elseif nX(2,k+1)<0

    f = nX(2,k) /(nX(2,k) - nX(2,k+1));
end
v(k+1) = V(k+1)/m(k+1);
x = [p(k+1);T(k+1)];
A = [v(k+1)*p(k+1) - (R(k+1)*T(k+1));-1*v(k+1)*p(k+1) + (cp(k+1)*T(k+1))];
b = [0;f*((Hf*mf)/m(k+1))*dt - (v(k+1)*p(k))+ (cp(k+1)*T(k))];
x =A/ b;
mf(k+1) = mf(k) + (f*mf*dt);
end
while phi(k) < 3*pi -EXH

for i = 1:5
   nX(i,k+1) = nX(i,k);
   muX(i,k+1) = muX(i,k);
end
n(k+1) = n(k)*(V(k+1)/V(k));
m(k+1) = m(k)*(V(k+1)/V(k));
R(k+1) = R(k);
cp(k+1) = cp(k);
cv(k+1) = cv(k);
v(K+1) = V(K+1)/m(k+1);
p(k+1) = p(k)*((v(k)/v(k+1))^(cp(k+1)/cv(k+1)));
T(k+1) = (p(k+1)*v(k+1))/R(k+1);

end
while (3*pi) -EXH <=phi(k) && phi(k) < 4*pi
for i = 1:5

    muX(i,k+1) = muX(i,k);
end

gamma = cp(k)/cv(k);
R(k+1) = R(k);
cp(k+1) = cp(k);
cv(k+1) = cv(k);
mE = CE * ((pi*(Dv^2))/4)* (p(k)/sqrt(R(k)*T(k)))*nthroot(pa/p(k),gamma)*sqrt((gamma*2)/(gamma-1)*(1-((pa/p(k))^((gamma-1)/gamma))));
CE = (.45+(3*((rpm-800)/5200)))*(1+(CR-8.854)/4);


end

while mE*dt< m(k)

m(k+1) = m(k) - (dt*mE);
n(k+1) = n(k) - ((dt*mE)/MMW);
for i =1:5

nX(i,k+1) = nX(i,k)*(n(k+1)/n(k));

end
mCO2 = mCO2 +(dt*mE*muX(5));

end


end
s(1) =4E3;
W(k+1) = W(k) + (.5*(p(k+1)+p(k))*(V(k+1)-V(k)));
s(k+1) = s(k) + (cv(k+1)*ln(T(k+1)/T(k))) + (R(k+1)*ln(v(k+1)/v(k)));


end
etaC = 1 - (T(1)/T(N));
eta = W(N)/(mf*Hf);

Kine(1,:) = phi; %rads
Kine(2,:) = t; % seconds
Kine(3,:) = V; % m^3
Kine(4,:) = W; % net work J


Therm(1,:) = p;
Therm(2,:) = T;
Therm(3,:) = v;
Therm(4,:) = s;

Chem(1,:) = n;
Chem(2,:) = m;
Chem(3:7,:) = muX;
Chem(8:12,:) = nX;

Diag(1,:) = eta;
Diag(2,:) = etaC;
Diag(3,:) = mf;
Diag(4,:) = mCO2;

