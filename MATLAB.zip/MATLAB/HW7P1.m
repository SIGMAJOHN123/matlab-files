x = 1;

for n  = 1:9
if n>1
x = (x*10)+n;
else 
 x = x;
end
P = (x*8) + n;
   
   fprintf('%9d x 8 + %d = %-9d\n', x,n, '=' + P)
end