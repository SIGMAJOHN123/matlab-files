function [T,iter] = IGTemperature(P,V,n)
% P = bar ... V = m^3 n = mols ... T = K
format long 
%   Detailed explanation goes here
c = 15.989;
d = 0.02541;
Ru = 0.08314;
T = 30;
Tgi = 300;
Tga = zeros(10);
Tga(1) = Tgi;
for iter = 2:numel(Tga)
if abs((P*(V/n - d)  /Ru  +   (c/Ru *(V/n -d)) / (V/n *(V/n + d ) *sqrt(P*(V/n - d)  /Ru  +   (c/Ru *(V/n -d)) / (V/n *(V/n + d ) *sqrt(T))))-Tga(iter))/Tga(iter))
if iter == 2
   
T = (P * (V/n - d)) / Ru + ((c / Ru) * (V/n - d)) / ((V/n) * (V/n + d) * sqrt(T));
Tga(iter) = T;
   
elseif iter  <= 100

    T = P*(V/n - d)  /Ru  +   (c/Ru *(V/n -d)) / (V/n *(V/n + d ) *sqrt(T));
    Tga(iter)=T;
end    
else
    break
end







end