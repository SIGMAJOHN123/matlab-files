n = transpose([0.1:.1:1]);
V = transpose([0.1:.05:.55]);
T = transpose([390:-10:300]);
[P_IG, P_vdW,P_RK]=IGPressure_Array(n,T,V);
RD_vdW = ((abs(P_vdW-P_IG))./(P_IG))*100;
RD_RK = (((abs(P_RK-P_IG))./(P_IG)))*100;
IGPressure_Data= [n V T P_IG P_vdW P_RK RD_vdW RD_RK];