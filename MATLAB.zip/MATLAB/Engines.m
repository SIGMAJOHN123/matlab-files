

VO = .6 ;%cm
D = .065; %cm
d = .1; %cm
rpm = 3000; %rpm
CR = VO +((D *(pi*(d^2)))/VO);
[Kine,Therm,Chem,Diag,DDT] = EngineCycle(D,d,rpm,'gasoline');
power = 1.34102E-2 *Kine(4,256);
gals = (Kine(3,256)/Kine(2,256))/3600;
MCO2 = Diag(4,256)/Kine(2,256)*1000;

fprintf('\n%25s\n', '1-CYLINDER ENGINE');
fprintf('%20s %-d\n', 'RPM:', rpm);
fprintf('%20s %5.1f cm\n', 'Crankshaft Diameter:', D);
fprintf('%20s %5.1f cm\n', 'Cylinder Diameter:', d);
fprintf('%20s %5.2f\n', 'Compression Ratio:', CR);

fprintf('\n%25s\n', 'GASOLINE');
fprintf('%20s %8.3f\n', 'Real Efficiency:', Diag(1,1));
fprintf('%20s %8.3f\n', 'Carnot Efficiency:', Diag(1,2));
fprintf('%20s %8.2f g/s\n', 'Carbon Dioxide Emission:', MCO2);
fprintf('%20s %8.1f hp\n', 'Power:', power);
fprintf('%20s %8.1f gal/hr\n', 'Fuel Use:', gals);


[Kine,Therm,Chem,Diag,DDT] = EngineCycle(D,d,rpm,"diesel");

power = 1.34102E-2 *Kine(4,256);
gals = (Kine(3,256)/Kine(2,256))/3600;
MCO2 = Diag(4,256)/Kine(2,256)*1000;


fprintf('\n%25s\n', 'diesel');
fprintf('%20s %8.3f\n', 'Real Efficiency:', Diag(1,1));
fprintf('%20s %8.3f\n', 'Carnot Efficiency:', Diag(1,2));
fprintf('%20s %8.2f g/s\n', 'Carbon Dioxide Emission:', MCO2);
fprintf('%20s %8.1f hp\n', 'Power:', power);
fprintf('%20s %8.1f gal/hr\n', 'Fuel Use:', gals);