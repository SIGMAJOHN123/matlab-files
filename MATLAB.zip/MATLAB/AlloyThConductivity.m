function [k,Error_Alloy,Error_T] = AlloyThConductivity(T,Alloy)


 if Alloy == "A91350"
     Error_Alloy=false;
    
     if (293<=T) && (T<498)

k = (1.244 * (10^-6)*(T^3))-(1.806*(10^-3)*(T^2))+((8.308E-1)*T)+(1.170E2);
Error_T = false;

     elseif (498<=T) && (T<933)

Error_T=false;
k = ((6.510E-10)*(T^4))-((1.787E-6)*(T^3))+((1.772E-3)*(T^2))-((8.156E-1)*T)+(3.836E2);
     else 
         Error_T= true;
         k = -1;
     end
 elseif Alloy == "C10100" 
Error_Alloy = false;
if (35<T) && (T<=160)
Error_T = false;

k = ((4.982E-6)*(T^4))-((2.824E-3)*(T^3))+((5.924E-1)*(T^2))-(54.83*T)+(2.305E3);
elseif (160<T) && (T<=300)
Error_T = false;

k = ((-1.266E-5)*(T^3))+((8.964E-3)*(T^2))-((2.115*T))+(5.553E2);
elseif (300<T) && (T<=1000)
Error_T = false;

k = ((2.024E-10)*(T^4))-((4.877E-7)*(T^3))+((3.565E-4)*(T^2))-((1.216E-1)*T)+(4.023E2);
else
    Error_T = true;
    k = -1;
end
 else
     Error_Alloy = true;
     Error_T = true;
     k = -1;

end