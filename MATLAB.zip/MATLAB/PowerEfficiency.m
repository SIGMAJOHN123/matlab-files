d = linspace(9.5,11.5,25);
D = linspace(5.5,9.5,25);
VO = .0060;
CRg = zeros(1,25);
CRd = zeros(1,25);
powerd = zeros(1,25);
powerg = zeros(1,25);
efg = zeros(1,25);
efd = zeros(1,25);
for i = 1:25

 [dKine,dTherm,dChem,dDiag,~] = EngineCycle(D(i),d(i),3000,"diesel")
CRd(i) = ( VO+ (D*((pi * d^2)/4)))/VO;
powerd(i) = 1.34102E-2 *dKine(4,256);
efd(i) = dDiag;
 [gKine,gTherm,gChem,gDiag,~] = EngineCycle(D(i),d(i),3000,"gasoline")
CRg = ( VO+ (D*((pi * d^2)/4)))/VO;
powerg(i) = 1.34102E-2 *gKine(4,256);
efg(i) = gdiag;
end
figure(1)
plot(powerg,CRg,':b',powerd,CRd,'-.r')

figure(2)
plot(efd,CRg,':b',efg,CRd,'-.r')