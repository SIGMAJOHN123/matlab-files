function [y,N] = Trigf(x,tol)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
format("long")
if x <= -1
y = -pi/2;


 
    for N = 0:100
y = y - (-1)^N * 1 / ((2*N + 1) * (x^(2*N + 1)));
disp(y)

if abs((-1)^N * 1 / ((2*N + 1) * (x^(2*N + 1)))) < tol
    break
end
    end






elseif x>-1 && x<1
y = 0;
N = 0;

while N < 100
    

    y = y +(-1)^N * (x^(2*N + 1)) / (2*N + 1);
if abs((-1)^N * (x^(2*N + 1)) / (2*N + 1)) < tol
    break
end 
    N = N+1;

end



elseif x >= -1
y = pi/2;
N = 0;
disp('p')

while N >= 0
y = y - (-1)^N * (1 / ((2*N + 1) * x^(2*N + 1)));
N = N + 1;
if abs((-1)^N * (1 / ((2*N + 1) * x^(2*N + 1)))) <tol
break
end
end
end