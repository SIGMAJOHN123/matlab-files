[T,iter] = IGTemperature(3.5,1.5,0.25)

Tga(7)