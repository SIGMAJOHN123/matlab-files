function [vmol,P_Gas] = NonIGPressure_SpecificGas(v,T,Gas)
% NonIGPRessure
Constants=importdata("GasConstants.xlsx");

Ru = 8.314;
switch Gas
    case {'C4H10','c4h10', 'C4h10', 'c4H10'}
M = Constants.data(1,1); 
a =  Constants.data(1,2); 
A =  Constants.data(1,3); 
b = Constants.data(1,4); 
B = Constants.data(1,5); 
c = Constants.data(1,6); 
C = Constants.data(1,7); 
alpha = Constants.data(1,8); 
gamma = Constants.data(1,9);
    case {'CO2', 'Co2', 'cO2'} 
M = Constants.data(2,1); 
a =  Constants.data(2,2); 
A =  Constants.data(2,3); 
b = Constants.data(2,4); 
B = Constants.data(2,5); 
c = Constants.data(2,6); 
C = Constants.data(2,7); 
alpha = Constants.data(2,8); 
gamma = Constants.data(2,9);
    case {'C0', 'c0'}
M = Constants.data(3,1); 
a = Constants.data(3,2); 
A = Constants.data(3,3); 
b =Constants.data(3,4); 
B = Constants.data(3,5); 
c = Constants.data(3,6); 
C = Constants.data(3,7); 
alpha = Constants.data(3,8); 
gamma = Constants.data(3,9);
    case {'CH4','Ch4','ch4','cH4'}
 M = Constants.data(4,1); 
a =  Constants.data(4,2); 
A =  Constants.data(4,3); 
b = Constants.data(4,4); 
B = Constants.data(4,5); 
c = Constants.data(4,6); 
C =Constants.data(4,7); 
alpha = Constants.data(4,8); 
gamma = Constants.data(4,9);
    case {'N2','n2'}
 
 M = Constants.data(5,1); 
a =  Constants.data(5,2); 
A =  Constants.data(5,3); 
b = Constants.data(5,4); 
B =Constants.data(5,5); 
c = Constants.data(5,6); 
C = Constants.data(5,7); 
alpha =Constants.data(5,8); 
gamma = Constants.data(5,9);
end




vmol = (v)*M;
P_Gas = (((Ru)*(T))/vmol)+((((B)*(Ru)*(T))-A-((C)/((T)^2)))*((vmol)^-2)) + ((((((b)*(Ru)*(T))-a)/((vmol)^3))))+(((a)*(alpha))/((vmol)^6))+(((c)/(((vmol)^3)*((T)^2)))*(1+((gamma)/((vmol)^2)))*exp(-(gamma)/((vmol)^2))); 
end
