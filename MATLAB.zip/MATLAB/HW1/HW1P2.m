% define constants
Ru = 0.08314; %[(bar*m^3)/(Kmol*K)] universal gas constant   
V = 0.325; %[m^3]
n = 0.0345; %[kmol of air] 
T = 300; %[K]
% air constants 
a = 1.368;
b = 0.0367;
c = 15.989;
d = 0.02541;


% equations 
P_IG = (n*Ru*T)/V

P_vdW = ((Ru*T)/((V/n)-b))-(a/((V/n)^2))

P_RK = ((Ru*T)/((V/n)-d))-(c/((V/n)*(sqrt(T)*((V/n)+d))))



% calculate differences 


RD_vdW = ((abs(P_vdW-P_IG))/P_IG)*100

RD_RK = ((abs(P_RK-P_IG))/P_IG)*100