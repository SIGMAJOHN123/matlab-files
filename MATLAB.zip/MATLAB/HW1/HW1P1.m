x1 = sqrt( 0.8467E-4 );

x2 = exp( -13 / 7 );

x3 = log(7.546E3 -58 / 26 );

xa = (2.794/12.345) + 17.25;

xc = 235/xa;

xd = 451.642-xc;

xb = nthroot( (xd)^9,7);

x4 = nthroot( xb  , 5 );


X = x1*(x2+x3-x4)



ya = cosd(75)*tan(pi/8)^2;

y1 = ((sin(pi/5))/ya);

y2a = asin(sqrt(3)/2);
y2b = (y2a/2)^0.642;

y2 = cos(y2b)^2;



y3 = 1/exp(log10( 106.15 * 10.35 ));


Y = y1 + y2 + y3
