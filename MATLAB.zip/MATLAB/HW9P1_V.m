format short
u = [1;-3;sqrt(6)];
v = [-2 ; 5; -3];
w = [4 ; 8 ;-8];


% PART C

magu = norm(u)
magv = norm(v) %  basically sqrt(38)
magw = norm(w)

 % PART D
unitw = w/norm(w)

% PART E
X = 6.*unitw

% PART F
disvw = norm(v-w)

% PART G
dotvw = dot(v,w);
magvw=magv .* magw;
lol = dotvw/magvw;
theta = acosd(lol)

% PART H
norm(v+w) <= (magv + magw)

publish('HW9P1_V','pdf')

